package com.qingping.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

object EventStore {
    private const val PREFS = "qingping_local_events"
    private const val KEY = "events_json"
    private val _events = MutableStateFlow<List<AdEvent>>(emptyList())
    val events = _events.asStateFlow()
    private var loaded = false
    private var nextId = 1L

    @Synchronized
    fun load(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = runCatching { JSONArray(prefs.getString(KEY, "[]")) }.getOrElse { JSONArray() }
        val list = mutableListOf<AdEvent>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            list += AdEvent(
                o.optLong("id"), o.optString("packageName"), o.optString("appLabel"),
                o.optLong("time"), o.optString("type"), o.optString("detail")
            )
        }
        _events.value = list.sortedByDescending { it.time }
        nextId = (list.maxOfOrNull { it.id } ?: 0L) + 1L
        loaded = true
    }

    @Synchronized
    fun add(context: Context, packageName: String, appLabel: String, type: String, detail: String) {
        if (!loaded) load(context)
        val newEvent = AdEvent(nextId++, packageName, appLabel, System.currentTimeMillis(), type, detail)
        val updated = (listOf(newEvent) + _events.value).take(500)
        _events.value = updated
        persist(context, updated)
    }

    @Synchronized
    fun clear(context: Context) {
        _events.value = emptyList()
        persist(context, emptyList())
    }

    private fun persist(context: Context, list: List<AdEvent>) {
        val arr = JSONArray()
        list.forEach { e ->
            arr.put(JSONObject().apply {
                put("id", e.id); put("packageName", e.packageName); put("appLabel", e.appLabel)
                put("time", e.time); put("type", e.type); put("detail", e.detail)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
