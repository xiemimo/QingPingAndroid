package com.qingping.app

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val events = remember { mutableStateListOf<AdEvent>() }
            var serviceEnabled by remember { mutableStateOf(isAccessibilityEnabled()) }
            LaunchedEffect(Unit) {
                EventStore.events.collectLatest { list ->
                    events.clear()
                    events.addAll(list)
                }
            }
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF9CE7FF),
                    secondary = Color(0xFFB7A7FF),
                    background = Color(0xFF0B1020),
                    surface = Color(0xCC202A40)
                )
            ) {
                HomeScreen(
                    events = events,
                    serviceEnabled = serviceEnabled,
                    onEnable = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                    onRefresh = { serviceEnabled = isAccessibilityEnabled() },
                    onClear = { EventStore.clear(this@MainActivity) }
                )
            }
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName &&
                it.resolveInfo.serviceInfo.name == AdAccessibilityService::class.java.name }
    }
}

@Composable
private fun HomeScreen(
    events: List<AdEvent>,
    serviceEnabled: Boolean,
    onEnable: () -> Unit,
    onRefresh: () -> Unit,
    onClear: () -> Unit
) {
    val bg = Brush.linearGradient(listOf(Color(0xFF10172B), Color(0xFF172C42), Color(0xFF241F43)))
    val detected = events.count { it.type == "检测" }
    val attempts = events.count { it.type == "干预" }
    val confirmed = events.count { it.type == "确认" }
    val perApp = events.groupBy { it.appLabel.ifBlank { it.packageName } }
        .mapValues { (_, v) -> v.count { it.type == "确认" } }
        .filterValues { it > 0 }
        .toList().sortedByDescending { it.second }

    Surface(modifier = Modifier.fillMaxSize(), color = Color.Transparent) {
        Box(Modifier.fillMaxSize().background(bg)) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("清屏", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("让每一次打开应用，都更清爽一点。", color = Color(0xFFB8C5DB), fontSize = 14.sp)
                }
                item {
                    GlassCard {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.weight(1f)) {
                                Text("检测服务", color = Color(0xFFB8C5DB), fontSize = 13.sp)
                                Text(if (serviceEnabled) "已授权 · 等待事件" else "尚未启用", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                                Text("需要在系统设置中手动开启无障碍服务", color = Color(0xFF9EABC2), fontSize = 11.sp)
                            }
                            Button(onClick = if (serviceEnabled) onRefresh else onEnable) {
                                Text(if (serviceEnabled) "刷新状态" else "去开启")
                            }
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatCard("检测事件", detected.toString(), Modifier.weight(1f))
                        StatCard("干预尝试", attempts.toString(), Modifier.weight(1f))
                        StatCard("确认成功", confirmed.toString(), Modifier.weight(1f))
                    }
                }
                item {
                    GlassCard {
                        Text("应用拦截排行", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        if (perApp.isEmpty()) {
                            Text("还没有确认拦截记录。启用服务后，数据会在本机逐步累积。", color = Color(0xFFB8C5DB), fontSize = 13.sp)
                        } else {
                            perApp.take(8).forEachIndexed { index, pair ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("${index + 1}. ${pair.first}", color = Color.White, modifier = Modifier.weight(1f))
                                    Text("${pair.second} 次", color = Color(0xFF9CE7FF), fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
                item {
                    GlassCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("最近事件", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            TextButton(onClick = onClear) { Text("清空记录") }
                        }
                        if (events.isEmpty()) {
                            Text("暂无事件记录", color = Color(0xFFB8C5DB), fontSize = 13.sp)
                        } else {
                            events.take(30).forEach { event ->
                                Column(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(event.appLabel.ifBlank { event.packageName }, color = Color.White, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                                        Text(event.type, color = when (event.type) {
                                            "确认" -> Color(0xFF8BE6B0)
                                            "干预" -> Color(0xFFFFD27D)
                                            else -> Color(0xFF9CE7FF)
                                        }, fontSize = 12.sp)
                                    }
                                    Text("${formatTime(event.time)} · ${event.detail}", color = Color(0xFF9EABC2), fontSize = 11.sp)
                                }
                                HorizontalDivider(color = Color(0x22FFFFFF))
                            }
                        }
                    }
                }
                item {
                    Text("清屏只对可识别的界面尝试操作；未知界面不会盲目点击。统计保存在本机。", color = Color(0xFF8795AD), fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun GlassCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth()
            .background(Color(0x332E4665), RoundedCornerShape(24.dp))
            .padding(18.dp),
        content = content
    )
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(Color(0x332E4665), RoundedCornerShape(20.dp))
            .padding(12.dp)
    ) {
        Text(title, color = Color(0xFFB8C5DB), fontSize = 11.sp)
        Spacer(Modifier.height(8.dp))
        Text(value, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
    }
}

private fun formatTime(time: Long): String =
    SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault()).format(Date(time))
