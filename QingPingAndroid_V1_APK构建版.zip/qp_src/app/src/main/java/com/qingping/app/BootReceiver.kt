package com.qingping.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        EventStore.load(context)
        EventStore.add(
            context, context.packageName, "清屏", "检测",
            "设备已启动。请检查无障碍服务是否由系统恢复；系统不保证自动重启服务。"
        )
        // Intentionally do not start a background service from boot.
        // The user can reopen QingPing and enable the accessibility service if needed.
    }
}
