package com.qingping.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AdAccessibilityService : AccessibilityService() {
    private val recent = mutableMapOf<String, Long>()
    private val exactSkipLabels = setOf("跳过广告", "跳过广告 >", "Skip Ad", "Skip ads", "Skip advertisement")

    override fun onServiceConnected() {
        super.onServiceConnected()
        EventStore.load(this)
        EventStore.add(this, packageName, "清屏", "检测", "无障碍服务已连接")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val targetPackage = event.packageName?.toString() ?: return
        if (targetPackage == packageName) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_VIEW_CLICKED) return

        val now = System.currentTimeMillis()
        val key = "$targetPackage:${event.eventType}"
        if (now - (recent[key] ?: 0L) < 1800L) return
        recent[key] = now

        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(targetPackage, 0)).toString()
        } catch (_: Exception) { targetPackage }

        val root = rootInActiveWindow
        if (root == null) {
            EventStore.add(this, targetPackage, label, "检测", "界面节点不可访问")
            return
        }

        val skipNode = findExplicitSkipNode(root)
        if (skipNode != null) {
            EventStore.add(this, targetPackage, label, "检测", "发现明确的跳过广告控件")
            EventStore.add(this, targetPackage, label, "干预", "尝试点击明确的跳过广告控件")
            val clicked = try {
                if (skipNode.isClickable) skipNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                else {
                    var parent = skipNode.parent
                    var success = false
                    var depth = 0
                    while (parent != null && depth < 4 && !success) {
                        if (parent.isClickable) success = parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        val next = parent.parent
                        parent.recycle()
                        parent = next
                        depth++
                    }
                    success
                }
            } catch (_: Exception) { false }
            EventStore.add(
                this, targetPackage, label,
                if (clicked) "确认" else "干预",
                if (clicked) "系统接受了点击操作；不代表已验证广告完全消失" else "点击操作未成功"
            )
        } else {
            EventStore.add(this, targetPackage, label, "检测", "收到界面变化事件；未找到明确的跳过广告控件")
        }
    }

    private fun findExplicitSkipNode(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < 250) {
            val node = queue.removeFirst()
            visited++
            val text = node.text?.toString()?.trim()
            val desc = node.contentDescription?.toString()?.trim()
            if (((text != null && text in exactSkipLabels) || (desc != null && desc in exactSkipLabels)) && node.isEnabled) {
                queue.forEach { it.recycle() }
                return node
            }
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let(queue::add)
            }
            if (node !== root) node.recycle()
        }
        return null
    }

    override fun onInterrupt() = Unit
}
