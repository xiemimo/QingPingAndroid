package com.qingping.app

data class AdEvent(
    val id: Long,
    val packageName: String,
    val appLabel: String,
    val time: Long,
    val type: String,
    val detail: String
)
